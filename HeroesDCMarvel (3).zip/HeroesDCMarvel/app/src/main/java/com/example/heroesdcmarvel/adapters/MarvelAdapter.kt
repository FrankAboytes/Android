package com.example.heroesdcmarvel.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.heroesdcmarvel.R
import com.example.heroesdcmarvel.models.Marvel

class MarvelAdapter(val marvels: List<Marvel>)
    : RecyclerView.Adapter<MarvelViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MarvelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.category2_item, parent, false)
        return MarvelViewHolder(view)
    }

    override fun getItemCount(): Int {
        return marvels.count()
    }

    override fun onBindViewHolder(holder: MarvelViewHolder, position: Int) {
        val marvel = marvels[position]
        holder.marvelTextView.text = marvel.name
        // Puedes usar una librería como Picasso o Glide para cargar imágenes
        // Ejemplo con Picasso (asegúrate de agregar la dependencia):
        // Picasso.get().load(marvel.imageUrl).into(holder.marvelImage)
    }
}

class MarvelViewHolder(view: View) : ViewHolder(view) {
    val marvelImage: ImageView = view.findViewById(R.id.marvel_image)
    val marvelTextView: TextView = view.findViewById(R.id.marvel_name)
}
