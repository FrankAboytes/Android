package com.example.heroesdcmarvel

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.heroesdcmarvel.models.User
import com.example.heroesdcmarvel.ui.HomeActivity
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    lateinit var loginBtn : Button
    lateinit var emailEt : EditText
    lateinit var passwordEt : EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val sharedPreferences = getSharedPreferences("PREFS", MODE_PRIVATE)
        val isLogged = sharedPreferences.getBoolean("isLogged", false)
        val intent = Intent(this@MainActivity, HomeActivity::class.java)
        if (isLogged) {
            startActivity(intent)
            finish()
        }
        loginBtn = findViewById(R.id.loginBtn)
        emailEt = findViewById(R.id.emailET)
        passwordEt = findViewById(R.id.passwordET)
        val user = User.staticUsers

        loginBtn.setOnClickListener {
            Log.i("LOGAPP", "Iniciar sesion")
            val email = emailEt.text.toString()
            val password = passwordEt.text.toString()
            Log.i("Email", email)
            Log.i("Password", password)
            if (email.isEmpty() || password.isEmpty()) {
                Log.i("ERROR", "La contraseña o el correo electornico esta vacío")
                return@setOnClickListener
            }
//            var isvalidUser = false
//            for (user in User.staticUsers) {
            //              if(user.email == email && user.password == password){
            //                isvalidUser = true
            //          }
            //    }
            val isValidUser = User.staticUsers.any { user ->
                user.email == email && user.password == password
            }
            if(!isValidUser) {
                Log.i("Error", "El correo o la contraseña son invalidos")
                return@setOnClickListener
            }
            val editor = sharedPreferences.edit()
            editor.putBoolean("isLogged", true)
            editor.apply()
            startActivity(intent)
            finish()
        }
    }
}